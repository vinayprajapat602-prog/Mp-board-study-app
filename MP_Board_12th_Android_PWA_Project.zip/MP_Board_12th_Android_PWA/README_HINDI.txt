MP Board 12th Study App — Android PWA project

इस ZIP में आपकी दी हुई HTML ऐप को PWA-ready बनाया गया है:
- index.html: आपकी मूल ऐप
- manifest.webmanifest: ऐप का नाम/आइकन/standalone सेटिंग
- sw.js: ऐप shell caching
- icons/: ऐप आइकन

महत्वपूर्ण:
1. यह ZIP अभी APK नहीं है।
2. APK बनाने के लिए इस फ़ोल्डर को HTTPS वेबसाइट पर publish करना होगा।
3. फिर PWABuilder जैसी packaging service में वेबसाइट URL देकर Android package बनाया जा सकता है।
4. आपकी HTML में Tailwind, Font Awesome और Google Fonts CDN से लोड होते हैं; इसलिए पहली बार और कुछ styling/fonts के लिए इंटरनेट की जरूरत रह सकती है।
5. ऐप का timetable/progress localStorage में रहता है; browser/app data साफ करने पर यह डेटा मिट सकता है।
6. पहले मोबाइल Chrome में hosted URL खोलकर जांचें, फिर Add to Home screen / Install करें।
